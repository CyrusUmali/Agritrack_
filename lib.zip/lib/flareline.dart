
import 'package:flareline/routes.dart';

class Flareline {

  static var routes = MAIN_PAGES;
}
